// DAYLILY - Simple planner functionality using plain JavaScript

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const SELF_CARE_ITEMS = [
  "Drink enough water", "Take a proper break", "Read a few pages",
  "Get some fresh air", "Do something I enjoy", "Tidy my space"
];
const QUOTES = [
  "Little by little, a little becomes a lot.",
  "You do not have to do it all today.",
  "Progress is still progress, no matter how small.",
  "Make space for the things that make you feel alive.",
  "A gentle reminder: you are doing better than you think.",
  "Start where you are. Use what you have. Do what you can.",
  "Give yourself the same kindness you give to others."
];

const STORAGE_KEY = "daylilyPlannerData";
const defaultData = {
  profile: { name: "", bio: "", goals: "", avatar: "" },
  tasks: [],
  goals: [],
  notes: [],
  ratings: {},
  selfCare: {},
  selectedDay: "Monday"
};

let data = loadData();
let selectedDay = data.selectedDay || DAYS[0];

// Save all planner information in this browser.
function loadData() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return saved ? { ...structuredClone(defaultData), ...saved } : structuredClone(defaultData);
  } catch (error) {
    return structuredClone(defaultData);
  }
}
function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}
function makeId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}
function todayKey() {
  // Convert today's weekday to the Monday-Sunday planner format.
  const jsDay = new Date().getDay(); // Sunday = 0
  return DAYS[jsDay === 0 ? 6 : jsDay - 1];
}
function getTasks(day) {
  return data.tasks.filter(task => task.day === day);
}
function getCompletedCount(tasks) {
  return tasks.filter(task => task.done).length;
}
function getAllCompleted() {
  return getCompletedCount(data.tasks);
}
function getProgress() {
  return data.tasks.length ? Math.round(getAllCompleted() / data.tasks.length * 100) : 0;
}

// Set up day selectors in both task forms.
function fillDaySelectors() {
  ["taskDay", "editTaskDay"].forEach(id => {
    const select = document.getElementById(id);
    select.innerHTML = DAYS.map(day => `<option value="${day}">${day}</option>`).join("");
  });
  document.getElementById("taskDay").value = todayKey();
}

// Show the selected page and update the sidebar highlight.
function showPage(pageName) {
  document.querySelectorAll(".page").forEach(page => page.classList.remove("active-page"));
  const page = document.getElementById(`page-${pageName}`);
  if (page) page.classList.add("active-page");

  document.querySelectorAll(".nav-link[data-page]").forEach(button => {
    button.classList.toggle("active", button.dataset.page === pageName);
  });

  if (pageName === "week") renderWeek();
  if (pageName === "todo") renderAllTasks();
  if (pageName === "goals") renderGoals();
  if (pageName === "stats") renderStats();
  if (pageName === "notes") renderNotes();
  if (pageName === "selfcare") renderSelfCare();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function updateProfileDisplay() {
  const name = data.profile.name || "sunshine";
  document.getElementById("helloName").textContent = name;
  document.getElementById("topName").textContent = name;
  document.getElementById("profileDisplayName").textContent = name;
  document.getElementById("profileName").value = data.profile.name || "";
  document.getElementById("profileBio").value = data.profile.bio || "";
  document.getElementById("profileGoals").value = data.profile.goals || "";

  ["topAvatar", "profileAvatar"].forEach(id => {
    const avatar = document.getElementById(id);
    avatar.innerHTML = data.profile.avatar
      ? `<img src="${data.profile.avatar}" alt="Your profile photo">`
      : "✿";
  });
}

function renderHome() {
  const today = todayKey();
  const tasks = getTasks(today);
  document.getElementById("homeCompleted").textContent = getCompletedCount(tasks);
  document.getElementById("homePending").textContent = tasks.filter(task => !task.done).length;
  document.getElementById("homeProgress").textContent = `${getProgress()}%`;
  document.getElementById("homeProgressText").textContent = `${getAllCompleted()} of ${data.tasks.length} tasks completed this week`;

  const list = document.getElementById("homeTaskList");
  const preview = tasks.slice(0, 4);
  list.className = preview.length ? "task-list" : "task-list empty-message";
  list.innerHTML = preview.length ? preview.map(task => taskHTML(task, false)).join("") :
    "Nothing on your list yet. Add a little task to get started.";

  const mood = data.ratings[today]?.mood;
  document.querySelectorAll("#homeMoodPicker button").forEach(button => {
    button.classList.toggle("selected", Number(button.dataset.mood) === Number(mood));
  });
  document.getElementById("moodSavedText").textContent = mood
    ? `You checked in with yourself today. Rating: ${data.ratings[today].rating || mood}/5 ♡`
    : "Your check-in is just for you.";
  document.getElementById("dailyQuote").textContent = QUOTES[new Date().getDay()];
}

function taskHTML(task, showDay = true) {
  const dayText = showDay ? `${task.day} · ` : "";
  return `
    <div class="task-row">
      <input class="task-check" type="checkbox" data-action="toggle-task" data-id="${task.id}" ${task.done ? "checked" : ""} aria-label="Mark task complete">
      <div class="task-main">
        <div class="task-name ${task.done ? "done" : ""}">${escapeHTML(task.title)}</div>
        <div class="task-meta">
          <span>${dayText}${task.time ? escapeHTML(task.time) : "No time set"}</span>
          <span class="priority ${task.priority}">${task.priority} priority</span>
        </div>
      </div>
      <div class="task-actions">
        <button class="icon-button" data-action="edit-task" data-id="${task.id}" aria-label="Edit task">✎</button>
        <button class="icon-button" data-action="delete-task" data-id="${task.id}" aria-label="Delete task">×</button>
      </div>
    </div>`;
}

function renderWeek() {
  const tabs = document.getElementById("weekTabs");
  tabs.innerHTML = DAYS.map(day => `
    <button class="day-tab ${day === selectedDay ? "selected" : ""}" data-select-day="${day}">
      <span>${day.slice(0, 3).toUpperCase()}</span><strong>${day.slice(0, 3)}</strong>
    </button>`).join("");

  document.getElementById("selectedDayTitle").textContent = selectedDay;
  const tasks = getTasks(selectedDay);
  document.getElementById("selectedDaySummary").textContent = `${getCompletedCount(tasks)} of ${tasks.length} tasks completed · ${tasks.length ? "You're making progress!" : "A fresh page for the day."}`;
  const list = document.getElementById("selectedDayTasks");
  list.className = tasks.length ? "task-list" : "task-list empty-message";
  list.innerHTML = tasks.length ? tasks.map(task => taskHTML(task, false)).join("") :
    "No plans for this day yet. Add your first task!";
}

function renderAllTasks() {
  const filter = document.getElementById("taskFilter").value;
  let tasks = [...data.tasks];
  if (filter === "pending") tasks = tasks.filter(task => !task.done);
  if (filter === "done") tasks = tasks.filter(task => task.done);
  tasks.sort((a, b) => DAYS.indexOf(a.day) - DAYS.indexOf(b.day) || (a.time || "").localeCompare(b.time || ""));
  const list = document.getElementById("allTaskList");
  list.className = tasks.length ? "task-list" : "task-list empty-message";
  list.innerHTML = tasks.length ? tasks.map(task => taskHTML(task, true)).join("") :
    "Your list is clear. Add something you'd like to get done.";
}

function renderGoals() {
  const list = document.getElementById("goalList");
  list.className = data.goals.length ? "goal-list" : "goal-list empty-message";
  list.innerHTML = data.goals.length ? data.goals.map(goal => `
    <div class="goal-row ${goal.done ? "completed" : ""}">
      <input type="checkbox" data-action="toggle-goal" data-id="${goal.id}" ${goal.done ? "checked" : ""} aria-label="Complete goal">
      <span>${escapeHTML(goal.title)}</span>
      <button data-action="delete-goal" data-id="${goal.id}" aria-label="Delete goal">×</button>
    </div>`).join("") : "Your goals will show up here.";
}

function renderNotes() {
  const list = document.getElementById("noteList");
  list.innerHTML = data.notes.length ? data.notes.map(note => `
    <article class="note-card">
      <h3>${escapeHTML(note.title)}</h3>
      <p>${escapeHTML(note.body || "A little note to yourself.")}</p>
      <button data-action="delete-note" data-id="${note.id}">Delete note</button>
    </article>`).join("") : '<p class="empty-message">No notes just yet. Save a thought when one comes along.</p>';
}

function renderSelfCare() {
  const today = todayKey();
  const checked = data.selfCare[today] || [];
  const list = document.getElementById("selfCareList");
  list.innerHTML = SELF_CARE_ITEMS.map((item, index) => `
    <div class="selfcare-item">
      <input type="checkbox" id="care-${index}" data-care-index="${index}" ${checked.includes(index) ? "checked" : ""}>
      <label for="care-${index}">${item}</label>
    </div>`).join("");
  document.getElementById("selfCareProgress").textContent = `${checked.length} of ${SELF_CARE_ITEMS.length} little moments checked off today ♡`;
}

function calculateStreak() {
  // Count backwards from today while each day has at least one completed task.
  let streak = 0;
  const today = new Date();
  for (let offset = 0; offset < 7; offset++) {
    const date = new Date(today);
    date.setDate(today.getDate() - offset);
    const jsDay = date.getDay();
    const dayName = DAYS[jsDay === 0 ? 6 : jsDay - 1];
    const completed = getTasks(dayName).some(task => task.done);
    if (completed) streak++;
    else if (offset > 0) break;
  }
  return streak;
}

function renderStats() {
  const completed = getAllCompleted();
  const pending = data.tasks.length - completed;
  document.getElementById("statCompleted").textContent = completed;
  document.getElementById("statPending").textContent = pending;
  document.getElementById("statRate").textContent = `${getProgress()}%`;
  document.getElementById("statStreak").textContent = `${calculateStreak()} days`;

  const bars = document.getElementById("dailyBars");
  bars.innerHTML = DAYS.map(day => {
    const tasks = getTasks(day);
    const percent = tasks.length ? Math.round(getCompletedCount(tasks) / tasks.length * 100) : 0;
    return `<div class="bar-row"><span>${day.slice(0, 3)}</span><div class="bar-track"><div class="bar-fill" style="width:${percent}%"></div></div><span>${percent}%</span></div>`;
  }).join("");

  const ratings = Object.values(data.ratings).map(entry => Number(entry.rating)).filter(value => value > 0);
  const average = ratings.length ? (ratings.reduce((sum, value) => sum + value, 0) / ratings.length).toFixed(1) : "—";
  document.getElementById("averageRating").textContent = `${average} / 5`;
  document.getElementById("ratingHistory").textContent = ratings.length
    ? `${ratings.length} day${ratings.length === 1 ? "" : "s"} rated so far. Keep checking in with yourself.`
    : "Your daily ratings will appear here.";
}

function openEditTask(taskId) {
  const task = data.tasks.find(item => item.id === taskId);
  if (!task) return;
  document.getElementById("editTaskId").value = task.id;
  document.getElementById("editTaskTitle").value = task.title;
  document.getElementById("editTaskDay").value = task.day;
  document.getElementById("editTaskTime").value = task.time || "";
  document.getElementById("editTaskPriority").value = task.priority;
  document.getElementById("editTaskDialog").showModal();
}

function refreshAll() {
  saveData();
  renderHome();
  renderWeek();
  renderAllTasks();
  renderGoals();
  renderNotes();
  renderSelfCare();
  renderStats();
}

// Navigation buttons
document.querySelectorAll("[data-page]").forEach(button => {
  button.addEventListener("click", () => showPage(button.dataset.page));
});

// First-time welcome form
document.getElementById("welcomeForm").addEventListener("submit", event => {
  event.preventDefault();
  data.profile.name = document.getElementById("welcomeName").value.trim();
  saveData();
  document.getElementById("welcomeScreen").classList.add("hidden");
  document.getElementById("app").classList.remove("hidden");
  updateProfileDisplay();
  renderHome();
});

document.getElementById("taskForm").addEventListener("submit", event => {
  event.preventDefault();
  const title = document.getElementById("taskTitle").value.trim();
  if (!title) return;
  data.tasks.push({
    id: makeId(), title,
    day: document.getElementById("taskDay").value,
    time: document.getElementById("taskTime").value,
    priority: document.getElementById("taskPriority").value,
    done: false
  });
  event.target.reset();
  document.getElementById("taskDay").value = selectedDay;
  refreshAll();
});

document.getElementById("addTaskFromWeek").addEventListener("click", () => {
  document.getElementById("taskDay").value = selectedDay;
  showPage("todo");
  document.getElementById("taskTitle").focus();
});

document.getElementById("taskFilter").addEventListener("change", renderAllTasks);

// Handle task actions using one event listener for all task lists.
document.addEventListener("click", event => {
  const actionButton = event.target.closest("[data-action]");
  if (!actionButton) return;
  const { action, id } = actionButton.dataset;

  if (action === "edit-task") openEditTask(id);
  if (action === "delete-task") {
    if (confirm("Delete this task?")) {
      data.tasks = data.tasks.filter(task => task.id !== id);
      refreshAll();
    }
  }
  if (action === "delete-goal") {
    data.goals = data.goals.filter(goal => goal.id !== id);
    refreshAll();
  }
  if (action === "delete-note") {
    data.notes = data.notes.filter(note => note.id !== id);
    refreshAll();
  }
});

document.addEventListener("change", event => {
  const control = event.target;
  if (control.dataset.action === "toggle-task") {
    const task = data.tasks.find(item => item.id === control.dataset.id);
    if (task) task.done = control.checked;
    refreshAll();
  }
  if (control.dataset.action === "toggle-goal") {
    const goal = data.goals.find(item => item.id === control.dataset.id);
    if (goal) goal.done = control.checked;
    refreshAll();
  }
  if (control.dataset.careIndex !== undefined) {
    const day = todayKey();
    data.selfCare[day] = data.selfCare[day] || [];
    const index = Number(control.dataset.careIndex);
    if (control.checked && !data.selfCare[day].includes(index)) data.selfCare[day].push(index);
    if (!control.checked) data.selfCare[day] = data.selfCare[day].filter(item => item !== index);
    refreshAll();
  }
});

document.getElementById("weekTabs").addEventListener("click", event => {
  const button = event.target.closest("[data-select-day]");
  if (!button) return;
  selectedDay = button.dataset.selectDay;
  data.selectedDay = selectedDay;
  saveData();
  renderWeek();
});

document.getElementById("editTaskForm").addEventListener("submit", event => {
  event.preventDefault();
  const task = data.tasks.find(item => item.id === document.getElementById("editTaskId").value);
  if (task) {
    task.title = document.getElementById("editTaskTitle").value.trim();
    task.day = document.getElementById("editTaskDay").value;
    task.time = document.getElementById("editTaskTime").value;
    task.priority = document.getElementById("editTaskPriority").value;
  }
  document.getElementById("editTaskDialog").close();
  refreshAll();
});
["closeEditDialog", "cancelEdit"].forEach(id => {
  document.getElementById(id).addEventListener("click", () => document.getElementById("editTaskDialog").close());
});

document.getElementById("goalForm").addEventListener("submit", event => {
  event.preventDefault();
  const input = document.getElementById("goalInput");
  const title = input.value.trim();
  if (!title) return;
  data.goals.push({ id: makeId(), title, done: false });
  input.value = "";
  refreshAll();
});

document.getElementById("noteForm").addEventListener("submit", event => {
  event.preventDefault();
  const title = document.getElementById("noteTitle").value.trim();
  const body = document.getElementById("noteBody").value.trim();
  if (!title) return;
  data.notes.unshift({ id: makeId(), title, body });
  event.target.reset();
  refreshAll();
});

document.getElementById("homeMoodPicker").addEventListener("click", event => {
  const button = event.target.closest("[data-mood]");
  if (!button) return;
  const mood = Number(button.dataset.mood);
  data.ratings[todayKey()] = { mood, rating: mood };
  refreshAll();
});

document.getElementById("profileForm").addEventListener("submit", event => {
  event.preventDefault();
  data.profile.name = document.getElementById("profileName").value.trim();
  data.profile.bio = document.getElementById("profileBio").value.trim();
  data.profile.goals = document.getElementById("profileGoals").value.trim();
  saveData();
  updateProfileDisplay();
  document.getElementById("profileSaveMessage").textContent = "Your profile has been saved ♡";
  renderHome();
});

document.getElementById("avatarUpload").addEventListener("change", event => {
  const file = event.target.files[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    alert("Please choose an image file.");
    return;
  }
  if (file.size > 1200000) {
    alert("Please choose an image smaller than 1.2 MB so it can be saved in your browser.");
    event.target.value = "";
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    data.profile.avatar = reader.result;
    saveData();
    updateProfileDisplay();
  };
  reader.readAsDataURL(file);
});

// Start the website.
function startDaylily() {
  fillDaySelectors();
  document.getElementById("todayLabel").textContent =
    new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" }).toUpperCase();

  if (data.profile.name) {
    document.getElementById("welcomeScreen").classList.add("hidden");
    document.getElementById("app").classList.remove("hidden");
    updateProfileDisplay();
    refreshAll();
  } else {
    document.getElementById("welcomeScreen").classList.remove("hidden");
    document.getElementById("app").classList.add("hidden");
  }
}
startDaylily();
